--Readers
DROP TABLE IF EXISTS [Readers];
CREATE TABLE [Readers](
[ReaderID] int primary key,
[ReaderName] varchar(50),
[ReaderLocalControllerID] int,
[ReaderHWID] int,
[ReaderStatus] int,
[CardFormatID] int,
[UseFacilityCodeAsReaderNumber] int,
[EntryZoneID] int,
[ExitZoneID] int,
[ControlBothDirections] int,
[DeactivateOutputOnDoorClosed] int,
[Input1LocalControllerID] int,
[InputHWID1] int,
[Output1LocalControllerID] int,
[OutputHWID1] int,
[Input2LocalControllerID] int,
[InputHWID2] int,
[Output2LocalControllerID] int,
[OutputHWID2] int,
[SafeInputHWID] int,
[SafeOutputHWID] int,
[OutputTime1] int,
[OpenTime] int,
[OutputTime2] int,
[MaxOpenTime] int,
[RexLocalControllerID] int,
[RexInputHWID] int,
[RexAccessTimeID] int,
[ReaderConnectedToIPReader] int,
[CheckTransitCount] int,
[CheckMealCount] int,
[CheckZoneMaxCount] int,
[CheckZoneMinCount] int,
[CheckSubZoneCount] int,
[CheckFacilityCode] int,
[CheckPIN] int,
[PINSize] int,
[PINTimeOut] int,
[ReadWithActiveInput] int,
[ReadWithActiveOutput] int,
[CanHaveDirectionInverted] int,
[DisplayID] int,
[CheckAccessTime] int,
[APBType] int,
[APBSuperviseOnly] int,
[ApbForgiveTime] int,
[MinTimeBetweenTransits] int,
[JustSuperviseMinTimeBetweenTransits] int,
[EscortType] int,
[EscortWithZoneCheckType] int,
[EscortTimeout] int,
[EscortReaders] varchar(50),
[SoundAlarm] int,
[ControlTA] int,
[ManualModeAccessTimeID] int,
[ManualModeTimeOut] int,
[RandomInspectionProbability] int,
[RandomInspectionLockTime] int,
[ForceInspectionLocalControllerID] int,
[ForceInspectionInputHWID] int,
[ReaderFloor] int,
[TKETargetMCO] varchar(25),
[TKETargetDevice] int,
[FaceMultiFactorForEntry] int
);

DROP INDEX IF EXISTS [IX_Readers_ReaderLocalControllerID_ReaderHWID];
CREATE UNIQUE INDEX [IX_Readers_ReaderLocalControllerID_ReaderHWID]
ON [Readers]([ReaderLocalControllerID] ASC, [ReaderHWID] ASC);

--CardFormats
DROP TABLE IF EXISTS [CardFormats];
CREATE TABLE [CardFormats](
[CardFormatID] int primary key,
[CardFormatLength] int,
[ID_StartBit_Field0] int,
[ID_EndBit_Field0] int,
[ID_StartBit_Field1] int,
[ID_EndBit_Field1] int,
[ID_StartBit_Field2] int,
[ID_EndBit_Field2] int,
[FC_StartBit] int,
[FC_EndBit] int,
[ID_ParityType] int,
[FC_ParityType] int);

--Inputs
DROP TABLE IF EXISTS [Inputs];
CREATE TABLE [Inputs](
[InputID] int,
[InputName] varchar(50),
[InputLocalControllerID] int,
[InputHWID] int,
[IsSupervised] int,
[IsInverted] int,
[SendStatusToServer] int,
[InputStatus] int);

DROP INDEX IF EXISTS [IX_Inputs_InputLocalControllerID_InputHWID];
CREATE UNIQUE INDEX [IX_Inputs_InputLocalControllerID_InputHWID]
ON [Inputs]([InputLocalControllerID] ASC, [InputHWID] ASC);

DROP INDEX IF EXISTS [IX_Inputs_InputID];
CREATE INDEX [IX_Inputs_InputID]
ON [Inputs]([InputID] ASC);

--Outputs
DROP TABLE IF EXISTS [Outputs];
CREATE TABLE [Outputs](
[OutputID] int,
[OutputName] varchar(50),
[OutputLocalControllerID] int,
[OutputHWID] int,
[OutputStatus] int);

DROP INDEX IF EXISTS [IX_Outputs_OutputLocalControllerID_OutputHWID];
CREATE UNIQUE INDEX [IX_Outputs_OutputLocalControllerID_OutputHWID]
ON [Outputs]([OutputLocalControllerID] ASC, [OutputHWID] ASC);

DROP INDEX IF EXISTS [IX_Outputs_OutputID];
CREATE INDEX [IX_Outputs_OutputID]
ON [Outputs]([OutputID] ASC);

--Actions
DROP TABLE IF EXISTS [Actions];
CREATE TABLE [Actions](
[ActionID] int primary key,
[ActionName] varchar(50),
[ActionCommandsQuery] varchar(2000)
);

--Commands
DROP TABLE IF EXISTS [Commands];
DROP TABLE IF EXISTS [ActionsFieldCommands];
CREATE TABLE [ActionsFieldCommands](
[ActionID] int,
[CommandIndex] int,
[CommandDelay] int,
[ObjectType] int,
[ObjectID] int,
[Command] int);

--DROP INDEX IF EXISTS [IX_ActionsFieldCommands_ActionID];
--CREATE UNIQUE INDEX [IX_ActionsFieldCommands_ActionID]
--ON [ActionsFieldCommands]([ActionID] ASC);

--ControllersGroup
DROP TABLE IF EXISTS [ControllersGroup];
CREATE TABLE [ControllersGroup](
[ControllerID] int primary key,
[IPAddress] varchar(15),
[Port] int,
[SameResetZoneGroup] int);

--Cards
DROP TABLE IF EXISTS [Cards];
CREATE TABLE [Cards](
[CardID] int primary key,
[CHID] int,
[ClearCode] varchar(50),
[CardNumber] int,
[FacilityCode] int,
[CardState] int,
[CardStartValidityDateTime] datetime,
[CardEndValidityDateTime] datetime,
[SubZoneID] int,
[MaxTransits] int,
[IgnoreTransitsCount] int,
[MaxMeals] int,
[IgnoreMealsCount] int,
[IgnoreAntiPassback] int,
[IgnoreZoneCount] int,
[IgnoreRandomInspection] int,
[PIN] varchar(10),
[RequiresEscort] int,
[CanEscort] int,
[GuardTourCard] int,
[CHName] varchar(20),
[CHFloor] int,
[CHUserID] int,
[CHGroup] int,
[Permission] int,
[TraceActionID] int);

DROP INDEX IF EXISTS [IX_Cards_CardID];
CREATE INDEX [IX_Cards_CardID]
ON [Cards]([CardID] ASC);

DROP INDEX IF EXISTS [IX_Cards_CHID];
CREATE INDEX [IX_Cards_CHID]
ON [Cards]([CHID] ASC);

DROP INDEX IF EXISTS [IX_Cards_CardNumber_FacilityCode];
CREATE INDEX [IX_Cards_CardNumber_FacilityCode]
ON [Cards]([CardNumber] ASC, [FacilityCode] ASC);

DROP INDEX IF EXISTS [IX_Cards_CardNumber_FacilityCode_CardState];
--CREATE INDEX [IX_Cards_CardNumber_FacilityCode_CardState]
--ON [Cards]([CardNumber] ASC, [FacilityCode] ASC, [CardState] ASC);

DROP INDEX IF EXISTS [IX_Cards_CardNumber_CardState];
--CREATE INDEX [IX_Cards_CardNumber_CardState]
--ON [Cards]([CardNumber] ASC, [CardState] ASC);

--CardsAccessLevels
DROP TABLE IF EXISTS [CardsAccessLevels];
DROP TABLE IF EXISTS [CHAccessLevels];
CREATE TABLE [CHAccessLevels](
[CHID] int,
[AccessLevelID] int,
[AccessLevelStartValidity] datetime,
[AccessLevelEndValidity] datetime);

DROP INDEX IF EXISTS [IX_CHAccessLevels_CHID];
CREATE INDEX [IX_CHAccessLevels_CHID]
ON [CHAccessLevels]([CHID] ASC);

--AccessLevels
DROP TABLE IF EXISTS [AccessLevels];
CREATE TABLE [AccessLevels](
[AccessLevelID] int primary key,
[AccessLevelName] varchar(50));

--AccessLevelsContent
DROP TABLE IF EXISTS [AccessLevelsContents];
CREATE TABLE [AccessLevelsContents](
[AccessLevelID] int,
[ReaderID] int,
[Direction] int,
[AccessTimeID] int,
[RequiresEscort] int,
[CanEscort] int
);

DROP INDEX IF EXISTS [IX_AccessLevelsContents_AccessLevelID];
CREATE INDEX [IX_AccessLevelsContents_AccessLevelID]
ON [AccessLevelsContents]([AccessLevelID] ASC);

DROP INDEX IF EXISTS [IX_AccessLevelsContents_ReaderID];
CREATE INDEX [IX_AccessLevelsContents_ReaderID]
ON [AccessLevelsContents]([ReaderID] ASC);

DROP INDEX IF EXISTS [IX_AccessLevels_ReaderHWID];
--CREATE INDEX [IX_AccessLevels_ReaderHWID]
--ON [AccessLevels]([AccessTimeHWID] ASC);

--AccessTimes
DROP TABLE IF EXISTS [AccessTimes];
CREATE TABLE [AccessTimes](
[AccessTimeID] int primary key,
[Sunday] int,
[SundayStartTime] datetime,
[SundayEndTime] datetime,
[Monday] int,
[MondayStartTime] datetime,
[MondayEndTime] datetime,
[Tuesday] int,
[TuesdayStartTime] datetime,
[TuesdayEndTime] datetime,
[Wednesday] int,
[WednesdayStartTime] datetime,
[WednesdayEndTime] datetime,
[Thursday] int,
[ThursdayStartTime] datetime,
[ThursdayEndTime] datetime,
[Friday] int,
[FridayStartTime] datetime,
[FridayEndTime] datetime,
[Saturday] int,
[SaturdayStartTime] datetime,
[SaturdayEndTime] datetime,
[Holiday] int,
[HolidayStartTime] datetime,
[HolidayEndTime] datetime);

--Holidays
DROP TABLE IF EXISTS [Holidays];
CREATE TABLE [Holidays](
[HolidayID] int primary key,
[HolidayDate] datetime);

--Zones
DROP TABLE IF EXISTS [Zones];
CREATE TABLE [Zones](
[ZoneID] int primary key,
[ZoneName] varchar(50),
[MaxNum] int,
[MinNum] int,
[MaxTime] int,
[MaxTimePreAlarm] int);

--SubZones
DROP TABLE IF EXISTS [SubZones];
CREATE TABLE [SubZones](
[SubZoneID] int primary key,
[SubZoneName] varchar(50),
[ZoneID] int,
[MaxNum] int);

DROP INDEX IF EXISTS [IX_SubZones_ZoneID];
CREATE INDEX [IX_SubZones_ZoneID]
ON [SubZones]([ZoneID] ASC);

--Reasons
DROP TABLE IF EXISTS [Reasons];
CREATE TABLE [Reasons](
[ReasonID] int primary key,
[ReasonHWID] int,
[ReasonText1] varchar(20),
[ReasonText2] varchar(20),
[ReasonText3] varchar(20),
[ReasonText4] varchar(20),
[ReasonActionID] int);

DROP INDEX IF EXISTS [IX_Reasons_ReasonHWID];
CREATE INDEX [IX_Reasons_ReasonHWID]
ON [Reasons]([ReasonHWID] ASC);

--EventMessages
DROP TABLE IF EXISTS [EventMessages];
CREATE TABLE [EventMessages](
[EventHWID] int primary key,
[EventText1] varchar(40),
[EventText2] varchar(40),
[EventText3] varchar(40),
[EventText4] varchar(40));

--ControllersLockGroup
DROP TABLE IF EXISTS [ControllersLockGroup];
CREATE TABLE [ControllersLockGroup](
[ControllerID] int primary key,
[IPAddress] varchar(15),
[Port] int);

--Schedules
DROP TABLE IF EXISTS [Schedules];
CREATE TABLE [Schedules](
[ScheduleID] int primary key,
[ScheduleEnabled] int,
[Occurrence] int,
[OccursOnceAt] datetime,
[StartDate] datetime,
[EnableEndDate] int,
[EndDate] datetime,
[RunEveryDayFreq] int,
[RunEveryWeekFreq] int,
[RunEveryMonthFreq] int,
[MonthlyOccurrence] int,
[DayInMonth] int,
[WeekNumber] int,
[DayInWeek] int,
[DailyFrequencyType] int,
[RunOnceAt] datetime,
[DailyFreqOccursEveryNum] int,
[DailyFreqOccursEveryUnit] int,
[DailyFreqStartTime] datetime,
[DailyFreqEndTime] datetime,
[Sunday] int,
[Monday] int,
[Tuesday] int,
[Wednesday] int,
[Thursday] int,
[Friday] int,
[Saturday] int,
[Holiday] int,
[January] int,
[February] int,
[March] int,
[April] int,
[May] int,
[June] int,
[July] int,
[August] int,
[September] int,
[October] int,
[November] int,
[December] int,
[ActionID] int);

--CHLinkedCHs
DROP TABLE IF EXISTS [CHLinkedCHs];
CREATE TABLE [CHLinkedCHs](
[CHID] int,
[LinkedCHID] int,
[EscortsLinkedCH] int,
[EscortedByLinkedCH] int);

DROP INDEX IF EXISTS [IX_CHLinkedCHs_CHID];
CREATE INDEX [IX_CHLinkedCHs_CHID]
ON [CHLinkedCHs]([CHID] ASC);

DROP INDEX IF EXISTS [IX_CHLinkedCHs_LinkedCHID];
CREATE INDEX [IX_CHLinkedCHs_LinkedCHID]
ON [CHLinkedCHs]([LinkedCHID] ASC);

--LocalControllers
DROP TABLE IF EXISTS [LocalControllers];
CREATE TABLE [LocalControllers](
[LocalControllerID] int primary key,
[LocalControllerName] varchar(50),
[LocalControllerType] int,
[LocalControllerStringID] varchar(50),
[IPAddress] varchar(50),
[BaseCommPort] int,
[DeviceID] int,
[LocalControllerEnabled] int,
[TraceEnabled] int,
[TraceSendIP] varchar(50),
[TraceSendPort] int,
[SiteControllerHostname] varchar(50),
[SiteControllerBaseCommPort] int,
[ApbCancelTimeout] int,
[IOIPMode] int,
[InterlockReaders] int,
[TurnOffOutputOnPulse] int,
[UserName] varchar,
[Password] varchar,
[ForceLocalAuthentication] int,
[IsEnrollTerminal] int,
[ExtraSettings] varchar
);

DROP INDEX IF EXISTS [IX_LocalControllers_LocalControllerType_IPAddress];
CREATE UNIQUE INDEX [IX_LocalControllers_LocalControllerType_IPAddress]
ON [LocalControllers]([LocalControllerType] ASC, [IPAddress] ASC);

DROP TABLE IF EXISTS [LocalControllersHenry];
CREATE TABLE [LocalControllersHenry](
[LocalControllerID] int primary key,
[HenryReader1Type] int,
[HenryReader1Direction] int,
[HenryReader2Type] int,
[HenryReader2Direction] int,
[HenryReader3Type] int,
[HenryReader3Direction] int,
[HenryReader4Type] int,
[HenryReader4Direction] int,
[HenryReader5Type] int,
[HenryReader5Direction] int,
[HenryReader6Type] int,
[HenryReader6Direction] int,
[HenryReaderKeyboardType] int,
[HenryReaderKeyboardDirection] int,
[HenryKeyboardFormat] int,
[HenryDefaultMessage] varchar(100)
);

-- [ReportOffline] int,
-- [SendTemplate] int,
-- [SendEventID] int,
-- [ReadersCheckFingerprints] int,
-- [KeyboardChecksFingerprints] int,
-- [AutoOn] int,
-- [BiometricIdentification] int,
-- [Biometry8x] int,
-- [Sensibility] int,
-- [ImageQuality] int,
-- [Luminosity] int,
-- [RegistrationType] int,
-- [FakeFingertipDetection] int,
-- [MinimumBiometryQuality] int,
-- [SecurityLevel] int,
-- [FastMode] int,
-- [OnlineBiometry] int,
-- [TemplateType] int,
-- [TemplateEncapsulation] int

DROP TABLE IF EXISTS [GroupsAccessLevels];
CREATE TABLE [GroupsAccessLevels](
    [GroupID] int,
    [AccessLevelID] int,
    [AccessLevelStartValidity] datetime,
    [AccessLevelEndValidity] datetime
);

DROP INDEX IF EXISTS [IX_GroupsAccessLevels_GroupID];
CREATE INDEX [IX_GroupsAccessLevels_GroupID]
ON [GroupsAccessLevels]([GroupID] ASC);


DROP TABLE IF EXISTS [ExpandedGroups];
CREATE TABLE [ExpandedGroups](
    [GroupID] int,
    [EffectiveGroupID] int
);

DROP INDEX IF EXISTS [IX_ExpandedGroups_GroupID];
CREATE INDEX [IX_ExpandedGroups_GroupID]
ON [ExpandedGroups]([GroupID] ASC);


DROP TABLE IF EXISTS [CHGroups];
CREATE TABLE [CHGroups](
    [CHID] int,
    [GroupID] int
);

DROP INDEX IF EXISTS [IX_CHGroups_CHID];
CREATE INDEX [IX_CHGroups_CHID]
ON [CHGroups]([CHID] ASC);

DROP TABLE IF EXISTS [Groups];
CREATE TABLE [Groups](
    [GroupID] int primary key,
    [GroupName] text
);

DROP TABLE IF EXISTS [LinkedGroups];
CREATE TABLE [LinkedGroups](
    [GroupID] int,
    [LinkedGroupID] int,
    [EscortsLinkedGroup] int,
    [EscortedByLinkedGroup] int
);

DROP INDEX IF EXISTS [IX_LinkedGroups_GroupID];
CREATE INDEX [IX_LinkedGroups_GroupID]
ON [LinkedGroups]([GroupID] ASC);

DROP INDEX IF EXISTS [IX_LinkedGroups_LinkedGroupID];
CREATE INDEX [IX_LinkedGroups_LinkedGroupID]
ON [LinkedGroups]([LinkedGroupID] ASC);

--EventsActions
DROP TABLE IF EXISTS [EventsActions];
CREATE TABLE [EventsActions](
    [SourceType] int,
    [SourceID] int,
    [EventHWID] int,
    [ActionID] int
);

DROP INDEX IF EXISTS [IX_EventsActions];
CREATE INDEX [IX_EventsActions]
ON [EventsActions]([SourceType], [SourceID], [EventHWID]);

--LastTransits
DROP TABLE IF EXISTS [LastTransits];
CREATE TABLE [LastTransits](
[CHID] int primary key,
[EventDateTime] datetime,
[ReaderID] int,
[ZoneID] int);

DROP INDEX IF EXISTS [IX_LastTransits_ZoneID];
CREATE INDEX [IX_LastTransits_ZoneID]
ON [LastTransits]([ZoneID]);

--FingerprintsHenry
DROP TABLE IF EXISTS [FingerprintsHenry];
CREATE TABLE [FingerprintsHenry](
[CHID] int,
[FingerIndex] int,
[Template] varchar);

DROP INDEX IF EXISTS [IX_FingerprintsHenry_CHID_FingerIndex];
CREATE INDEX [IX_FingerprintsHenry_CHID_FingerIndex]
ON [FingerprintsHenry]([CHID],[FingerIndex]);

DROP INDEX IF EXISTS [IX_FingerprintsHenry_CHID];
CREATE INDEX [IX_FingerprintsHenry_CHID]
ON [FingerprintsHenry]([CHID]);

--FingerprintsControlID
DROP TABLE IF EXISTS [FingerprintsControlID];
CREATE TABLE [FingerprintsControlID](
[CHID] int,
[FingerIndex] int,
[Template] varchar);

DROP INDEX IF EXISTS [IX_FingerprintsControlID_CHID_FingerIndex];
CREATE INDEX [IX_FingerprintsControlID_CHID_FingerIndex]
ON [FingerprintsControlID]([CHID],[FingerIndex]);

DROP INDEX IF EXISTS [IX_FingerprintsControlID_CHID];
CREATE INDEX [IX_FingerprintsControlID_CHID]
ON [FingerprintsControlID]([CHID]);

--FingerprintsZK
DROP TABLE IF EXISTS [FingerprintsZK];
CREATE TABLE [FingerprintsZK](
[CHID] int,
[FingerIndex] int,
[Template] varchar);

DROP INDEX IF EXISTS [IX_FingerprintsZK_CHID_FingerIndex];
CREATE INDEX [IX_FingerprintsZK_CHID_FingerIndex]
ON [FingerprintsZK]([CHID],[FingerIndex]);

DROP INDEX IF EXISTS [IX_FingerprintsZK_CHID];
CREATE INDEX [IX_FingerprintsZK_CHID]
ON [FingerprintsZK]([CHID]);

--FingerprintsZK
DROP TABLE IF EXISTS [GeneralSettings];
CREATE TABLE [GeneralSettings](
[CfgID] varchar,
[CfgValue] varchar);

DROP INDEX IF EXISTS [IX_GeneralSettings_CfgID];
CREATE INDEX [IX_GeneralSettings_CfgID]
ON [GeneralSettings]([CfgID]);

--FingerprintsIdemia
DROP TABLE IF EXISTS [FingerprintsIdemia];
CREATE TABLE [FingerprintsIdemia](
[CHID] int,
[FingerIndex] int,
[Template] varchar);

DROP INDEX IF EXISTS [IX_FingerprintsIdemia_CHID_FingerIndex];
CREATE INDEX [IX_FingerprintsIdemia_CHID_FingerIndex]
ON [FingerprintsIdemia]([CHID],[FingerIndex]);

DROP INDEX IF EXISTS [IX_FingerprintsIdemia_CHID];
CREATE INDEX [IX_FingerprintsIdemia_CHID]
ON [FingerprintsIdemia]([CHID]);


DROP TABLE IF EXISTS [BiometricData];
CREATE TABLE [BiometricData](
[CHID] int,
[Type] int,
[DataIndex] int,
[Duress] int,
[Data] varchar,
[LastUpdate] datetime);

DROP INDEX IF EXISTS [IX_BiometricData];
CREATE INDEX [IX_BiometricData_CHID_Type]
ON [BiometricData]([CHID],[Type]);

DROP TABLE IF EXISTS [LocalControllerTypesBioDataTypes];
CREATE TABLE [LocalControllerTypesBioDataTypes](
[LocalControllerType] int,
[BiometricDataType] int,
[BiometricCategory] int,
[CountLimit] int
);

DROP TABLE IF EXISTS [DuressFingers];
CREATE TABLE [DuressFingers](
[CHID] int,
[FingerIndex] int
);

DROP TABLE IF EXISTS [EscortReaders];
CREATE TABLE [EscortReaders](
[ReaderID] int,
[EscortReaderID] int
);
